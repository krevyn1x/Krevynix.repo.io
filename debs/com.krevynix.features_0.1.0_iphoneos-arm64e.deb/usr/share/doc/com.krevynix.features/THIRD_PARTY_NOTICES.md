# Credits and source boundaries

Krevynix is the developer of this independently assembled suite.

- StandBy Settings adapter: adapted from pookjw/StandPad, GPL-3.0. The included source and GPL license accompany every distribution containing that adapter.
- Dynamic Island visual repair: existing local Codex implementation, renamed and guarded for this suite. The rejected landscape adapter is excluded.
- Apple Turbo Boost: concept and research reference by Halo-Michael, https://github.com/Halo-Michael/Apple-Turbo-Boost/. The new profile validator and hook are independently implemented. The upstream repository has no explicit distribution license; its original code is excluded.
- ContactsFS: behavior reference by 0xkuj, https://github.com/0xkuj/ContactsFS. The photo transaction and user interface are independently implemented. No upstream code or assets are included.
- Watusi and Fouad's repository: feature and layout references, https://fouadraheb.com/apps/watusi and https://fouadraheb.com/apt. No licensed binaries, identity, icons, artwork, authentication, or proprietary implementation are redistributed.
- Apple, Adobe, WhatsApp, Sileo, Zebra, Installer and Cydia names identify compatible software; they do not imply endorsement.

Public source is licensed under GPL-3.0-or-later. Runtime evidence, account information, contact backups, and device dumps are excluded.
