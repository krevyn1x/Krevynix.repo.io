# Krevynix Cr4shed Repair

An independently authored companion for an already-installed Cr4shed app and daemon. It contains no Cr4shed, FRPreferences, libnotifications, or CrossOverIPC binaries or source. Krevynix is the companion's developer, author and maintainer. Original Cr4shed credit remains with Muirey03; the rootless fork belongs to CrazyMind90 and mhster_nice.

The original rootless post-install script re-signs executables with obsolete default signatures. This helper explicitly runs the installed Procursus `ldid -Hsha256 -Cadhoc -s` on private copies of the fixed app and daemon, verifies every arm64/arm64e slice, saves private originals, and atomically installs verified copies. It requires an explicit root terminal and offers no privilege escalation.

Native packages resolve bootstrap paths with KRVPaths: rootful, rootless and RootHide each compile separately. In a root terminal, invoke your bootstrap's path to `/usr/libexec/krevynix-cr4shed-repair`:

```sh
/var/jb/usr/libexec/krevynix-cr4shed-repair status
/var/jb/usr/libexec/krevynix-cr4shed-repair repair
/var/jb/usr/libexec/krevynix-cr4shed-repair restore
```

Use `/usr/libexec/...` for rootful; use the RootHide bootstrap's resolved executable path for RootHide. There are no arbitrary target-path arguments. `repair` and `restore` never restart processes or read personal crash logs. Open Cr4shed yourself after repair; an already-running daemon keeps its mapped executable until a later explicit launch. Package installation itself makes no changes to original Cr4shed files.

Backups reside in the bootstrap's private root-owned `/var/lib/krevynix/cr4shed-repair`, mode0700. `restore` refuses if an installed executable changed after repair. A prepared transaction can retire untouched originals or restore its own partially repaired bytes. Snapshots are kept after restoration. The verifier demands identical per-slice entitlement keys and values and identical non-signature payload, except the code-signature offset/size and `__LINKEDIT` size fields that necessarily change during signing.

Limits: this companion repairs signatures only. It does not update Cr4shed's private crash-report hooks, restore an absent app/dependency, or establish iOS18 Mach/jetsam reporting compatibility. Rootful and RootHide artifacts require their own device testing. No public redistribution of the original fork is authorized by its currently available license files.
